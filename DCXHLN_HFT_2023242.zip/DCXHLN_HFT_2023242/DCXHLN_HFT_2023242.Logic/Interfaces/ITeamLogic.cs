﻿using DCXHLN_HFT_2023242.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Logic
{
    public interface ITeamLogic
    {
        void Create(Team item);
        void Delete(int id);
        Team Read(int id);
        IEnumerable<Team> ReadAll();
        void Update(Team item);

        //non-cruds

        Team TeamWithMostValuablePlayer();
        IEnumerable<TeamWithValue> TeamWithValue();
        IEnumerable<Team> PlayerInTeam(string inputp);


    }
}
