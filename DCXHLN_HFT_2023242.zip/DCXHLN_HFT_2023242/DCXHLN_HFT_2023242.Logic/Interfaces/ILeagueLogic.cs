﻿using DCXHLN_HFT_2023242.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Logic
{
    public interface ILeagueLogic
    {
        void Create(League item);
        void Delete(int id);
        League Read(int id);
        IEnumerable<League> ReadAll();
        void Update(League item);

        //non-cruds
        League MostPlayer();
        IEnumerable<LeagueWithValue> LeagueWithValue();


    }
}
