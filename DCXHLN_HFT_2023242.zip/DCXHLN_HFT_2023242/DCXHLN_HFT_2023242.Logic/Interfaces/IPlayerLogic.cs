﻿using DCXHLN_HFT_2023242.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Logic
{
    public interface IPlayerLogic
    {
        void Create(Player item);
        void Delete(int id);
        Player Read(int id);
        IEnumerable<Player> ReadAll();
        void Update(Player item);
    }
}
