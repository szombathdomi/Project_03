﻿using DCXHLN_HFT_2023242.Repository;
using DCXHLN_HFT_2023242.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Logic
{
    public class PlayerLogic : IPlayerLogic
    {
        IRepository<Player> repo;

        public PlayerLogic(IRepository<Player> repo)
        {
            this.repo = repo;
        }

        public void Create(Player item)
        {
            if (item.PlayerId < 0)
            {
                throw new ArgumentException("The ID must be positive!");
            }
            if (item.Name.Length == 0)
            {
                throw new ArgumentException("Name is required!");
            }
            if (item.Market_value < 0)
            {
                throw new ArgumentException("The market value cannot be zero!");
            }
            if (item.TeamId <= 0)
            {
                throw new ArgumentException("There is no such team.");
            }
            this.repo.Create(item);
        }

        public void Delete(int id)
        {
            this.repo.Delete(id);
        }

        public Player Read(int id)
        {
            var player = this.repo.Read(id);
            if (player == null)
            {
                throw new ArgumentException("Player does not exist");
            }
            return this.repo.Read(id);
        }

        public IEnumerable<Player> ReadAll()
        {
            return this.repo.ReadAll();
        }

        public void Update(Player item)
        {
            this.repo.Update(item);
        }
    }
}
