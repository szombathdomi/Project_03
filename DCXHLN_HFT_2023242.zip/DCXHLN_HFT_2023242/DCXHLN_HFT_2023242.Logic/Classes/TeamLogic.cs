﻿using DCXHLN_HFT_2023242.Repository;
using DCXHLN_HFT_2023242.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Logic
{
    public class TeamLogic : ITeamLogic
    {
        IRepository<Team> repo;

        public TeamLogic(IRepository<Team> repo)
        {
            this.repo = repo;
        }

        public void Create(Team item)
        {
            if (item.TeamName.Length < 0)
            {
                throw new ArgumentException("There must be a name for the team.");
            }
            if (item.StadiumName.Length < 0)
            {
                throw new ArgumentException("There must be a arena for the team.");
            }
            if (item.LeagueId < 0)
            {
                throw new ArgumentException("There is no such league.");
            }
            this.repo.Create(item);
        }

        public void Delete(int id)
        {
            var t = this.repo.Read(id);
            if (t.Players.Count() > 0)
            {
                throw new ArgumentException("Team can not be deleted until it has Players.");
            }
            this.repo.Delete(id);
        }

        public Team Read(int id)
        {
            var team = this.repo.Read(id);
            if (team == null)
            {
                throw new ArgumentException("Team does not exist");
            }
            return this.repo.Read(id);
        }

        public IEnumerable<Team> ReadAll()
        {
            return this.repo.ReadAll();
        }

        public void Update(Team item)
        {
            this.repo.Update(item);
        }

        //non-cruds

        public Team TeamWithMostValuablePlayer()
        {
            return (from x in repo.ReadAll()
                    orderby x.Players.Max(s => s.Market_value) descending
                    select x).First();


        }

        public IEnumerable<TeamWithValue> TeamWithValue()
        {
            return (from x in repo.ReadAll()
                    select new TeamWithValue()
                    {
                        Name = x.TeamName,
                        Value = Math.Round(x.Players.Sum(p => p.Market_value),2)
                    });
        }

        public IEnumerable<Team> PlayerInTeam(string inputp)
        {
            return repo.ReadAll()
                .Where(t => t.Players.Any(p => p.Name == inputp));
        }
    }
    public class TeamWithValue
    {
        public string Name { get; set; }
        public double Value { get; set; }
        public TeamWithValue()
        {
        }
    }
}
