﻿
using DCXHLN_HFT_2023242.Repository;
using DCXHLN_HFT_2023242.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Logic
{
    public class LeagueLogic : ILeagueLogic
    {
        IRepository<League> repo;

        public LeagueLogic(IRepository<League> repo)
        {
            this.repo = repo;
        }

        public void Create(League item)
        {
            if (item.LeagueId < 0)
            {
                throw new ArgumentException("The ID must be positive!");
            }
            if (item.Name.Length == 0)
            {
                throw new ArgumentException("The given name is too short to be a valid League name!");
            }

            if (item.Sponsor is null)
            {
                throw new ArgumentException("There must be a sponsor!");
            }

            this.repo.Create(item);
        }

        public void Delete(int id)
        {
            var r = this.repo.Read(id);
            if (r.Teams.Count() > 0)
            {
                throw new ArgumentException("League can not be deleted until it has participating teams.");
            }
            this.repo.Delete(id);
        }

        public League Read(int id)
        {
            bool exist = false;
            foreach (var item in repo.ReadAll())
            {
                if (item.LeagueId == id)
                {
                    exist = true;
                }


            }
            if (!exist)
            {
                throw new ArgumentException("InvalidID");
            }
            var league = this.repo.Read(id);
            if (league == null)
            {
                throw new ArgumentNullException("League does not exists");
            }
            return league;
        }

        public IEnumerable<League> ReadAll()
        {
            return this.repo.ReadAll();
        }

        public void Update(League item)
        {
            this.repo.Update(item);
        }

        //non-cruds

        public League MostPlayer()
        {
            return (from x in repo.ReadAll()
                    orderby x.Teams.Sum(n => n.Players.Count()) descending
                    select x).First();
        }

        public IEnumerable<LeagueWithValue> LeagueWithValue()
        {
            return (from x in repo.ReadAll()
                    select new LeagueWithValue()
                    {
                        Name = x.Name,
                        Value = Math.Round(x.Teams.Sum(p => p.Players.Sum(s => s.Market_value)),2)
                    });
        }
    }

    public class LeagueWithValue
    {
        public string Name { get; set; }
        public double Value { get; set; }
        public LeagueWithValue()
        {
        }
    }
}
