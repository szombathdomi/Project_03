﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Models
{
    public class Team
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public string StadiumName { get; set; }
        public int StadiumCapacity { get; set; }


        public int LeagueId { get; set; }
        [NotMapped]
        [JsonIgnore]
        public virtual League Legaue { get; set; }
        [NotMapped]
        [JsonIgnore]
        public virtual ICollection<Player> Players { get; set; }

        public Team()
        {
        }

        public Team(int teamId, string teamName, string stadiumName, int stadiumCapacity, int leagueId)
        {
            TeamId = teamId;
            TeamName = teamName;
            StadiumName = stadiumName;
            StadiumCapacity = stadiumCapacity;
            Players = new HashSet<Player>();
            LeagueId = leagueId;
        }
    }
}
