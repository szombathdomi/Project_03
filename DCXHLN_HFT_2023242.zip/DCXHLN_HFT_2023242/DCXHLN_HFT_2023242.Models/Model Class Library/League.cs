﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DCXHLN_HFT_2023242.Models
{
    public class League
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int LeagueId { get; set; }
        public string Name { get; set; }
        public string Sponsor { get; set; }
        [NotMapped]
        [JsonIgnore]
        public virtual ICollection<Team> Teams { get; set; }
        public League()
        {
        }
        public League(int leagueId, string name, string sponsor)
        {
            LeagueId = leagueId;
            Name = name;
            Sponsor = sponsor;
            Teams = new HashSet<Team>();
        }
    }
}
