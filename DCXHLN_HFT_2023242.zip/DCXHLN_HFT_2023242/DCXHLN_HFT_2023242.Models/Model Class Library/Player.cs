﻿using DCXHLN_HFT_2023242.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace DCXHLN_HFT_2023242.Models
{
    public class Player
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PlayerId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public double Market_value { get; set; }

        //foreign key
        public int TeamId { get; set; }
        [NotMapped]
        [JsonIgnore]
        public virtual Team Team { get; set; }

        public Player()
        {
        }
        public Player(int playerId, string name, int age, double market_value, int teamId)
        {
            PlayerId = playerId;
            Name = name;
            Age = age;
            Market_value = market_value;
            TeamId = teamId;
        }
    }
}
