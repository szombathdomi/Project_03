﻿using DCXHLN_HFT_2023242.Logic;
using DCXHLN_HFT_2023242.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DCXHLN_HFT_2023242.Endpoint.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class TeamStatController : ControllerBase
    {
        ITeamLogic logic;

        public TeamStatController(ITeamLogic logic)
        {
            this.logic = logic;
        }

        // GET: api/values
        [HttpGet]
        public Team TeamWithMostValuablePlayer()
        {
            return this.logic.TeamWithMostValuablePlayer();
        }

        [HttpGet]
        public IEnumerable<TeamWithValue> TeamWithValue()
        {
            return this.logic.TeamWithValue();
        }

        [HttpGet("{inputp}")]
        public IEnumerable<Team> PlayerInTeam(string inputp)
        {
            return this.logic.PlayerInTeam(inputp);
        }
    }
}
