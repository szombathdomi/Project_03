﻿using DCXHLN_HFT_2023242.Logic;
using DCXHLN_HFT_2023242.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DCXHLN_HFT_2023242.Endpoint.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class LeagueStatController : ControllerBase
    {
        ILeagueLogic logic;

        public LeagueStatController(ILeagueLogic logic)
        {
            this.logic = logic;
        }

        // GET: api/values
        [HttpGet]
        public League MostPlayer()
        {
            return this.logic.MostPlayer();
        }

        [HttpGet]
        public IEnumerable<LeagueWithValue> LeagueWithValue()
        {
            return this.logic.LeagueWithValue();
        }
    }
}
