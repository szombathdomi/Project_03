﻿using System;
using DCXHLN_HFT_2023242.Models;
using System.Collections.Generic;
using System.Linq;
using ConsoleTools;
using ConsoleTables;

namespace DCXHLN_HFT_2023242.Client
{
    internal class Program
    {
        static RestService rest;
        static void Main(string[] args)
        {
            rest = new RestService("http://localhost:24023/", "League");

            var LeagueSubMenu = new ConsoleMenu(args, level: 1)
                  .Add("List", () => List("League"))
                  .Add("Create", () => Create("League"))
                  .Add("Delete", () => Delete("League"))
                  .Add("Update", () => Update("League"))
                  .Add("MostPlayer", () => MostPlayer())
                  .Add("LeagueWithValue", () => LeagueWithValue())
                  .Add("Exit", ConsoleMenu.Close);

            var TeamSubMenu = new ConsoleMenu(args, level: 1)
                .Add("List", () => List("Team"))
                .Add("Create", () => Create("Team"))
                .Add("Delete", () => Delete("Team"))
                .Add("Update", () => Update("Team"))
                .Add("TeamWithMostValuablePlayer", () => TeamWithMostValuablePlayer())
                .Add("TeamWithValue", () => TeamWithValue())
                .Add("PlayerInTeam", () => PlayerInTeam())
                .Add("Exit", ConsoleMenu.Close);

            var PlayerSubMenu = new ConsoleMenu(args, level: 1)
                .Add("List", () => List("Player"))
                .Add("Create", () => Create("Player"))
                .Add("Delete", () => Delete("Player"))
                .Add("Update", () => Update("Player"))
                .Add("Exit", ConsoleMenu.Close);


            var menu = new ConsoleMenu(args, level: 0)
                .Add("Leagues", () => LeagueSubMenu.Show())
                .Add("Team", () => TeamSubMenu.Show())
                .Add("Player", () => PlayerSubMenu.Show())
                .Add("Exit", ConsoleMenu.Close);

            menu.Show();
        }
        private static void Update(string entity)
        {
            if (entity == "League")
            {
                Console.Write("Enter League's ID to update: ");
                int leagueID = int.Parse(Console.ReadLine());
                League newLeague = rest.Get<League>(leagueID, "league");

                Console.Write("Do you want to change league name? (Y/N)");
                string decision = Console.ReadLine();

                if (decision == "Y")
                {
                    Console.Write($"New name (old: {newLeague.Name}): ");
                    string newName = Console.ReadLine();
                    newLeague.Name = newName;
                }
                Console.Write("Do you want to change league sponsor? (Y/N) ");
                decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New sponsor(old: {newLeague.Sponsor}): ");
                    string newSponsor = Console.ReadLine();
                    newLeague.Sponsor = newSponsor;
                }

                rest.Put(newLeague, "league");
            }
            if (entity == "Team")
            {
                Console.Write("Enter team's ID to update: ");
                int teamID = int.Parse(Console.ReadLine());
                Team newTeam = rest.Get<Team>(teamID, "team");

                Console.Write("Do you want to change team name? (Y/N)");
                string decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New team name (old: {newTeam.TeamName}): ");
                    string newName = Console.ReadLine();
                    newTeam.TeamName = newName;
                }
                Console.Write("Do you want to change team stadium? (Y/N)");
                decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New stadium (old: {newTeam.StadiumName}): ");
                    string newStadium = Console.ReadLine();
                    newTeam.StadiumName = newStadium;
                }
                Console.Write("Do you want to change the LeagueID? (Y/N)");
                decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New LeagueID (old: {newTeam.LeagueId}): ");
                    int newLeagueID = int.Parse(Console.ReadLine());
                    newTeam.LeagueId = newLeagueID;
                }

                rest.Put(newTeam, "team");
            }
            if (entity == "Player")
            {
                Console.Write("Enter player's ID to update: ");
                int playerID = int.Parse(Console.ReadLine());
                Player newPlayer = rest.Get<Player>(playerID, "player");

                Console.Write("Do you want to change player's name? (Y/N)");
                string decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New Player name (old: {newPlayer.Name}): ");
                    string newName = Console.ReadLine();
                    newPlayer.Name = newName;
                }
                Console.Write("Do you want to change player's age? (Y/N)");
                decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New age (old: {newPlayer.Age}): ");
                    int newAge = int.Parse(Console.ReadLine());
                    newPlayer.Age = newAge;
                }
                Console.Write("Do you want to change player's teamID? (Y/N)");
                decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New team ID (old: {newPlayer.TeamId})");
                    int newTeamID = int.Parse(Console.ReadLine());
                    newPlayer.TeamId = newTeamID;
                }
                Console.Write("Do you want to change player's market value? (Y/N)");
                decision = Console.ReadLine();
                if (decision == "Y")
                {
                    Console.Write($"New market value (old: {newPlayer.Market_value})");
                    int newmarket_Value = int.Parse(Console.ReadLine());
                    newPlayer.Market_value = newmarket_Value;
                }
                rest.Put(newPlayer, "player");
            }
        }

        private static void Delete(string entity)
        {
            if (entity == "League")
            {
                try
                {
                    Console.WriteLine("Enter league's ID to delete: ");
                    int LeagueID = int.Parse(Console.ReadLine());
                    rest.Delete(LeagueID, "league");
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                    Console.ReadKey();
                }
            }
            if (entity == "Team")
            {
                Console.WriteLine("Enter team's ID to delete: ");
                int TeamID = int.Parse(Console.ReadLine());
                rest.Delete(TeamID, "team");
            }
            if (entity == "Player")
            {
                Console.WriteLine("Enter player's ID to delete: ");
                int PlayerID = int.Parse(Console.ReadLine());
                rest.Delete(PlayerID, "player");
            }
        }

        private static void Create(string entity)
        {
            if (entity == "League")
            {
                Console.Write("Enter League name: ");
                string leagueName = Console.ReadLine();
                Console.Write("Enter League sponsor: ");
                string leagueSponsor = Console.ReadLine();
                rest.Post(new League()
                {
                    Name = leagueName,
                    Sponsor = leagueSponsor

                }, "league");
            }
            if (entity == "Team")
            {
                Console.Write("Enter team name: ");
                string teamName = Console.ReadLine();
                Console.Write("Enter team arena: ");
                string teamArena = Console.ReadLine();
                Console.Write("Enter leagueID: ");
                int teamLeagueID = int.Parse(Console.ReadLine());
                rest.Post(new Team()
                {
                    TeamName = teamName,
                    StadiumName = teamArena,
                    LeagueId = teamLeagueID
                }, "team");
            }
            if (entity == "Player")
            {
                Console.Write("Enter player name: ");
                string playerName = Console.ReadLine();
                Console.Write("Enter teamID: ");
                int playerTeamID = int.Parse(Console.ReadLine());
                Console.Write("Enter Age: ");
                int playerAge = int.Parse(Console.ReadLine());
                Console.Write("Enter player market value: ");
                int playerMarketvalue = int.Parse(Console.ReadLine());
                rest.Post(new Player()
                {
                    Name = playerName,
                    TeamId = playerTeamID,
                    Market_value = playerMarketvalue,
                    Age = playerAge
                }, "player");
            }
        }

        private static void List(string entity)
        {
            if (entity == "League")
            {
                List<League> leagues = rest.Get<League>("league");
                foreach (var item in leagues)
                {
                    Console.WriteLine(item.Name);
                }
            }
            else if (entity == "Team")
            {
                List<Team> teams = rest.Get<Team>("team");
                foreach (var item in teams)
                {
                    Console.WriteLine(item.TeamName);
                }
            }
            else if (entity == "Player")
            {
                List<Player> players = rest.Get<Player>("player");
                ;
                foreach (var item in players)
                {
                    Console.WriteLine(item.Name);
                }
            }
            Console.ReadKey();
        }

        private static void MostPlayer()
        {
            League result = rest.GetSingle<League>("LeagueStat/MostPlayer");
            Console.WriteLine("League with most player: " + result.Name);
            Console.ReadKey();
        }

        private static void LeagueWithValue()
        {
            var result = rest.Get<LeagueWithValue>("LeagueStat/LeagueWithValue");
            var table = new ConsoleTable("Name", "Value");
            foreach (var item in result)
            {
                table.AddRow(item.Name, item.Value);
            }
            table.Write(Format.Minimal);
            Console.ReadKey();
        }

        private static void TeamWithMostValuablePlayer()
        {
            Team result = rest.GetSingle<Team>("TeamStat/TeamWithMostValuablePlayer");
            Console.WriteLine("Team with most valuable player: " + result.TeamName);
            Console.ReadKey();
        }

        private static void TeamWithValue()
        {
            var result = rest.Get<TeamWithValue>("TeamStat/TeamWithValue");
            var table = new ConsoleTable("Name", "Value");
            foreach (var item in result)
            {
                table.AddRow(item.Name, item.Value);
            }
            table.Write(Format.Minimal);
            Console.ReadKey();
        }

        public static void PlayerInTeam()
        {
            Console.Write("Enter a player: ");
            string input = Console.ReadLine();
            var result = rest.Get<Team>($"TeamStat/PlayerInTeam/{input}");
            Console.WriteLine("Team with player: " + result[0].TeamName);
            Console.ReadKey();
        }
    }
    public class LeagueWithValue
    {
        public LeagueWithValue()
        {
        }
        public string Name { get; set; }
        public double Value { get; set; }
    }
    public class TeamWithValue
    {
        public TeamWithValue()
        {
        }
        public string Name { get; set; }
        public double Value { get; set; }
    }
}

