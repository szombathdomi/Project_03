﻿using DCXHLN_HFT_2023242.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace DCXHLN_HFT_2023242.Repository
{
    public class LeagueDbContext : DbContext
    {
        public DbSet<League> Leagues { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Player> Players { get; set; }

        public LeagueDbContext()
        {
            this.Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseLazyLoadingProxies().UseInMemoryDatabase("LeagueDb");
            }
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //connections
            modelBuilder.Entity<Team>()
                .HasOne(x => x.Legaue)
                .WithMany(x => x.Teams)
                .HasForeignKey(x => x.LeagueId);

            modelBuilder.Entity<Player>()
                .HasOne(x => x.Team)
                .WithMany(x => x.Players)
                .HasForeignKey(x => x.TeamId);

            //DbSeed
            var league = new List<League>()
            {
                new League(1,"Premier_League","Nike"),
                new League(2,"LaLiga","Adidas"),
                new League(3,"Seria_A","Kappa"),
            };
            modelBuilder.Entity<League>().HasData(league);

            var teams = new List<Team>()
            {
                //Premier_League
                new Team(1,"Arsenal","Emirates Stadion",60704,1),
                new Team(2,"Liverpool","Anfield",61276,1),
                new Team(3,"Manchester City","Etihad Stadion",55097,1),

                //LaLiga
                new Team(4,"Real Madrid","Estadio Santiago Bernabéu",83186,2),
                new Team(5,"FC Barcelona","Estadio Olímpico",54367,2),
                new Team(6,"Girona","Estadio Municipal de Montilivi",14624,2),

                //Seria_A
                new Team(7,"Inter","San Siro",80018,3),
                new Team(8,"AC Milan","Stadio Giuseppe Meazza",80019,3),
                new Team(9,"Juventus","Allianz Stadion",41507,3),
            };
            modelBuilder.Entity<Team>().HasData(teams);

            var players = new List<Player>()
            {
                //Arsenal_Players
                new Player(1,"Gabriel",26,64.5,1),
                new Player(2,"Kai Havertz",24,58.7,1),
                new Player(3,"Ben White",26,54.6,1),
                new Player(4,"David Raya",28,34.7,1),
                new Player(5,"Declan Rice",25,109.2,1),
                new Player(6,"William Saliba",23,76.0,1),

                //Liverpool_Players
                new Player(7,"Szoboszlai Dominik",23,77.7,2),
                new Player(8,"Mohamed Salah",24,58.7,2),
                new Player(9,"Alisson",26,54.6,2),
                new Player(10,"Virgil van Dijk",23,173.6,2),
                new Player(11,"Luis Diaz",32,64.7,2),
                new Player(12,"Cody Gakpo",31,53.9,2),

                //Manchester City_Players
                new Player(13,"Stefan Ortega",26,77.2,3),
                new Player(14,"Jeremy Doku",31,8.8,3),
                new Player(15,"Ederson",30,37.4,3),
                new Player(16,"Erling Haaland",23,173.6,3),
                new Player(17,"Kevin De Bruyne",32,64.7,3),
                new Player(18,"Phil Foden",23,129.1,3),


                //RealMadrid_Players
                new Player(19,"Vinicius Junior",23,157.4,4),
                new Player(20,"Jude Bellingham",20,196.6,4),
                new Player(21,"Rodrygo",23,102.1,4),
                new Player(22,"Andriy Lunin",25,16.1,4),
                new Player(23,"Daniel Carvajal",32,11.9,4),

                //FC Barcelona_Players
                new Player(24,"ter Stegen Marc-Andre",31,29.4,5),
                new Player(25,"Ronald Araujo",25,66.5,5),
                new Player(26,"Joao Cancelo",29,31.1,5),
                new Player(27,"Gavi",19,89.4,5),
                new Player(28,"Joao Felix",24,29.4,5),

                //Girona_Players
                new Player(29,"Daley Blind",34,3.0,6),
                new Player(30,"David Lopez",34,3,6),
                new Player(31,"Antal Yaakobishvili",19,4.5,6),
                new Player(32,"Aleix Garcia",26,25.2,6),
                new Player(33,"Savio",20,39.7,6),


                //Inter_Players
                new Player(34,"Yann Sommer",35,4.9,7),
                new Player(35,"Denzel Dumfries",28,26.8,7),
                new Player(36,"Kristjan Asllani",22,15.2,7),
                new Player(37,"Tajon Buchanan",25,7.5,7),

                //AC Milann_Players
                new Player(38,"Davide Bartesaghi",18,0.8,8),
                new Player(39,"Jan-Carlo Simic",18,4.8,8),
                new Player(40,"Malick Thiaw",22,28.9,8),
                new Player(41,"Rafael Leao",24,88.1,8),

                //Juventus_Players
                new Player(42,"Cerri Leonardo",21,0.5,9),
                new Player(43,"Chiesa Federico",26,39.1,9),
                new Player(44,"Iling Junior Samuel",20,11.2,9),
                new Player(45,"Kean Moise",24,17.6,9),
                new Player(46,"Milik Arkadiusz",30,6.4,9),
                new Player(47,"Sekulov Nikola",22,0.4,9),
                new Player(48,"Dusan Vlahovic",24,62.7,9),

            };
            modelBuilder.Entity<Player>().HasData(players);

            base.OnModelCreating(modelBuilder);
        }
    }
}
