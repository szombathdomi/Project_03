﻿using DCXHLN_HFT_2023242.Repository;
using DCXHLN_HFT_2023242.Logic;
using DCXHLN_HFT_2023242.Models;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DCXHLN_HFT_2023242.Test
{
    public class FakeLeagueRepository : IRepository<League>
    {
        public void Create(League item)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public League Read(int id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<League> ReadAll()
        {
            return new List<League>()
            {
                new League(1,"ALiga","ASponsor")
                {
                    Teams = new HashSet<Team>()
                    {
                        new Team(1,"1Team","1Stadion",1,1)
                        {
                            Players = new HashSet<Player>()
                            {
                                new Player(1,"AJatekos1",1,1,1),
                                new Player(2,"AJatekos2",2,2,1)
                            }
                        },
                        new Team(2,"2Team","2Stadion",2,1)
                        {
                            Players = new HashSet<Player>()
                            {
                                new Player(3,"AJatekos3",3,3,2),
                                new Player(4,"AJatekos4",4,4,2)
                            }
                        }
                    }
                },
                new League(2,"BLiga","BSponsor")
                {
                    Teams = new HashSet<Team>()
                    {
                        new Team(3,"3Team","3Arena",3,2)
                        {
                            Players = new HashSet<Player>()
                            {
                                new Player(5,"AJatekos5",5,5,3),
                                new Player(6,"AJAtekos6",6,6,3),
                            }
                        },
                        new Team(4,"4Team","4Arena",4,2)
                        {
                            Players = new HashSet<Player>()
                            {
                                new Player(7,"AJatekos7",7,7,4),
                                new Player(8,"AJatekos8",8,8,4),
                                new Player(9,"AJatekos9",9,9,4)
                            }
                        }
                    }
                }
            }.AsQueryable();
        }

        public void Update(League item)
        {
            throw new NotImplementedException();
        }
    }
    public class FakeTeamRepositroy : IRepository<Team>
    {
        public void Create(Team item)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public Team Read(int id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<Team> ReadAll()
        {
            return new List<Team>()
            {
                new Team(1,"Acsapat","Astadion",1,1)
                {
                    Players = new HashSet<Player>()
                    {
                        new Player(1,"AJatekos1",1,1,1),
                        new Player(2,"AJatekos2",2,2,1),
                        new Player(3,"AJatekos3",3,3,1)
                    }
                },

                new Team(2,"Bcsapat","Bstadion",2,1)
                {
                    Players = new HashSet<Player>()
                    {
                        new Player(4,"BJatekos1",4,4,2),
                        new Player(5,"BJatekos2",5,5,2),
                        new Player(6,"BJatekos3",6,6,2)
                    }
                },

                new Team(3,"Ccsapat","Cstadion",3,1)
                {
                    Players = new HashSet<Player>()
                    {
                        new Player(7,"CJatekos1",7,7,3),
                        new Player(8,"CJatekos2",8,8,3),
                        new Player(9,"CJatekos3",9,9,3)
                    }
                },
            }.AsQueryable();
        }
        public void Update(Team item)
        {
            throw new NotImplementedException();
        }
    }



    [TestFixture]
    public class Tester
    {
        LeagueLogic leagueLogic;
        LeagueLogic leagueLogicMoq;

        TeamLogic teamLogic;
        TeamLogic teamLogicMoq;

        Mock<IRepository<League>> mockLeagueRepository;
        Mock<IRepository<Team>> mockTeamRepository;

        [SetUp]
        public void Init()
        {
            leagueLogic = new LeagueLogic(new FakeLeagueRepository());
            teamLogic = new TeamLogic(new FakeTeamRepositroy());

            mockLeagueRepository = new Mock<IRepository<League>>();
            mockTeamRepository = new Mock<IRepository<Team>>();
            mockLeagueRepository.Setup(m => m.ReadAll()).Returns(leagueLogic.ReadAll().AsQueryable());
            mockTeamRepository.Setup(m => m.ReadAll()).Returns(teamLogic.ReadAll().AsQueryable());
            leagueLogicMoq = new LeagueLogic(mockLeagueRepository.Object);
            teamLogicMoq = new TeamLogic(mockTeamRepository.Object);
        }

        [Test]
        public void mostplayerTest()
        {
            var result = leagueLogic.MostPlayer();
            Assert.That(result.Name == "BLiga");
        }

        [Test]
        public void LeagueWithValueTest()
        {
            var result = leagueLogic.LeagueWithValue().ToList();

            var expected = new List<LeagueWithValue>()
            {
                new LeagueWithValue()
                {
                    Name = "ALiga",
                    Value = 10
                },
                new LeagueWithValue()
                {
                    Name = "BLiga",
                    Value = 35
                }
            };

            Assert.That(expected[0].Name == result[0].Name);
            Assert.That(expected[0].Name == result[0].Name);
            Assert.That(expected[1].Name == result[1].Name);
            Assert.That(expected[1].Name == result[1].Name);
        }

        [Test]
        public void TeamWithMostValuablePlayerTest()
        {
            var result = teamLogic.TeamWithMostValuablePlayer();
            Assert.That(result.TeamName == "Ccsapat");
        }

        [Test]
        public void TeamWithValueTest()
        {
            var result = teamLogic.TeamWithValue().ToList();

            var expected = new List<TeamWithValue>()
            {
                new TeamWithValue()
                {
                    Name = "Acsapat",
                    Value = 6

                },
                new TeamWithValue()
                {
                    Name = "Bcsapat",
                    Value = 15

                },
                new TeamWithValue()
                {
                    Name = "Ccsapat",
                    Value = 24

                }

            };
            Assert.That(expected[0].Value == result[0].Value);
            Assert.That(expected[0].Name == result[0].Name);
            Assert.That(expected[1].Value == result[1].Value);
            Assert.That(expected[1].Name == result[1].Name);
            Assert.That(expected[2].Value == result[2].Value);
            Assert.That(expected[2].Name == result[2].Name);
        }

        [Test]
        public void PlayerInTeamTest()
        {
            var result = teamLogic.PlayerInTeam("AJatekos1").ToList();

            var expected = new List<Team>()
            {
                new Team(1,"Acsapat","Astadion",1,1)
            };

            Assert.That(expected[0].TeamName == result[0].TeamName);
        }

        [Test]
        public void LeagueCreateTestWithInvalidItem()
        {
            League TestItem = null;

            try
            {
                leagueLogicMoq.Create(TestItem);
            }
            catch
            {

            }

            mockLeagueRepository.Verify(
                m => m.Create(TestItem),
                Times.Never);
        }

        [Test]
        public void LeagueCreateTestWithValidItem()
        {
            League TestItem = new League(5, "ZSLeague", "ZSSponsor");

            leagueLogicMoq.Create(TestItem);

            mockLeagueRepository.Verify(
                m => m.Create(TestItem),
                Times.Once);
        }

        [Test]
        public void LeagueReadTestWithInvalidItem()
        {

            try
            {
                leagueLogicMoq.Read(20);
            }
            catch
            {

            }

            mockLeagueRepository.Verify(
                m => m.Read(20),
                Times.Never);
        }


        [Test]
        public void TeamCreateTestWithInvalidItem()
        {
            Team TestItem = null;

            try
            {
                teamLogicMoq.Create(TestItem);
            }
            catch
            {

            }

            mockTeamRepository.Verify(
                m => m.Create(TestItem),
                Times.Never);
        }

        [Test]
        public void TeamCreateTestWithValidItem()
        {
            Team TestItem = new Team(10, "SzTeam", "SzAreba", 20, 2);

            teamLogicMoq.Create(TestItem);

            mockTeamRepository.Verify(
                m => m.Create(TestItem),
                Times.Once);
        }
    }
}
